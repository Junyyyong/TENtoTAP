package io.github.junyyyong.makezero;

import android.content.res.Configuration;
import android.os.Bundle;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyTextZoom();
    }

    @Override
    public void onResume() {
        super.onResume();
        applyTextZoom();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        applyTextZoom();
    }

    /** Keep the game's CSS type sizes, without changing OS density or magnification. */
    private void applyTextZoom() {
        if (bridge == null || bridge.getWebView() == null) return;
        WebView webView = bridge.getWebView();
        webView.getSettings().setTextZoom(100);
        // WebView may process the configuration after Activity's callback.
        webView.post(() -> {
            if (!isFinishing() && !isDestroyed() && bridge != null && bridge.getWebView() == webView) {
                webView.getSettings().setTextZoom(100);
            }
        });
    }
}
