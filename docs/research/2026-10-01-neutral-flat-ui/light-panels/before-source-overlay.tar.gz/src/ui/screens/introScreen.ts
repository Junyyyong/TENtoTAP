import { el, formatClock } from "../dom";
import type { Progress } from "../storage";
import type { GameMode } from "../../core/types";
import { initialLearningStage } from '../../content/testSettings';

/**
 * What a mode is, before it starts.
 *
 * Time attack and endless used to begin the instant they were tapped, which
 * gave the player no moment to see what they were about to be measured on.
 * One screen each: the name, the number that defines it, and the records to
 * beat.
 */
const TITLES: Partial<Record<GameMode, string>> = {
  timeAttack: "LIMITLESS",
  endless: "ENDLESS",
  timeless: "TIMELESS",
};

const NOTES: Partial<Record<GameMode, string>> = {
  timeAttack: "Make 10, stage by stage",
  endless: "It ends when the board fills",
  timeless: "Empty the board with 10, 20, 30",
};

/** The picture on the plate, one per mode. */
const ART: Partial<Record<GameMode, string>> = {
  timeAttack: "./stopwatch-60.svg",
  timeless: "./stopwatch-forever.svg",
  endless: "./infinity.svg",
};

export class IntroScreen {
  private readonly title = el<HTMLHeadingElement>("intro-title");
  private readonly mark = el<HTMLDivElement>("intro-mark");
  private readonly art = el<HTMLImageElement>("intro-mark-art");
  private readonly note = el<HTMLParagraphElement>("intro-note");
  private readonly stats = el<HTMLElement>("intro-stats");
  private mode: GameMode = "timeAttack";

  constructor(onStart: (mode: GameMode) => void, onBack: () => void) {
    el<HTMLButtonElement>("btn-intro-back").addEventListener("click", onBack);
    el<HTMLButtonElement>("btn-intro-start").addEventListener("click", () => onStart(this.mode));
  }

  render(mode: GameMode, progress: Progress, bestEndlessTime: number): void {
    this.mode = mode;
    el("btn-intro-start").textContent = "START";
    this.title.textContent = TITLES[mode] ?? "ENDLESS";
    /*
     * The one thing that says what the mode is.
     *
     * Both of the timed ones show it on a stopwatch face: sixty for the run
     * that is over in a minute, and the sign for forever on the one with no
     * clock at all. Endless gets the sign without a watch around it — its
     * clock counts up rather than down, and nothing is measured against it.
     */
    this.art.src = ART[mode] ?? ART.endless!;
    this.mark.classList.toggle("endless", mode === "endless");
    this.note.textContent = NOTES[mode] ?? "";
    if (mode === "timeAttack") {
      const seconds = initialLearningStage(progress.learningStage) <= 5 ? 15 : 60;
      // Keep the original mode icon; the note conveys the stage's actual time.
      this.note.textContent = initialLearningStage(progress.learningStage) > 30 ? 'Score in 60 seconds' : `${seconds} seconds per stage`;
    }

    const rows: [string, string][] =
      mode === "timeAttack"
        ? [initialLearningStage(progress.learningStage) > 30 ? ["ROUND", "60 SECONDS"] : ["STAGE", String(initialLearningStage(progress.learningStage))], ["BEST SCORE", progress.bestLimitlessScore.toLocaleString()]]
        : mode === "timeless"
          ? [
              ["BEST SCORE", progress.bestTimeless.toLocaleString()],
              ["FEWEST LEFT", progress.fewestLeft < 0 ? "--" : String(progress.fewestLeft)],
            ]
          : [
              ["BEST SCORE", progress.bestEndless.toLocaleString()],
              ["BEST TIME", bestEndlessTime === 0 ? "--:--" : formatClock(bestEndlessTime)],
            ];

    this.stats.replaceChildren(
      ...rows.flatMap(([label, value]) => {
        const name = document.createElement("dt");
        name.textContent = label;
        const number = document.createElement("dd");
        number.textContent = value;
        return [name, number];
      }),
    );
  }
}
