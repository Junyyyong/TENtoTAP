import { TOTAL_STAGES } from "../content/chapters";
import { Capacitor } from '@capacitor/core';
import { Preferences } from '@capacitor/preferences';
import { PersistentStore, savedObject } from './persistentStore';

// These names identify user data, not the app release. Never rename them for
// a version bump; missing fields are added by the readers below.
const DAILY_KEY = "makezero.daily.v1";
const PROGRESS_KEY = "makezero.progress.v1";
const SETTINGS_KEY = "makezero.settings.v1";
const store = new PersistentStore(
  () => localStorage,
  Capacitor.isNativePlatform() ? Preferences : undefined,
);

export const initializeStorage = (): Promise<void> =>
  store.initialize([DAILY_KEY, PROGRESS_KEY, SETTINGS_KEY]);
export const flushStorage = (): Promise<void> => store.flush();
export function onStorageSaveFailure(handler: (failed: boolean) => void): void {
  store.onSaveFailure = handler;
}

export interface DailyStats {
  date: string;
  best: number;
  games: number;
}

export interface Progress {
  /** Highest stage the player may enter, 1-based. */
  stage: number;
  bestStory: number;
  bestTimeAttack: number;
  bestTimeAttackLevels: number[];
  learningStage: number;
  bestLearningScore: number;
  bestLimitlessScore: number;
  bestEndless: number;
  /** Longest an endless run has survived, in milliseconds. */
  bestEndlessMs: number;
  /** Best score in TIMELESS. */
  bestTimeless: number;
  /** Fewest blocks ever left standing there. -1 until a run has finished. */
  fewestLeft: number;
  /** Chapters whose story beat has already played. */
  seenChapters: string[];
  /** Best star grade per stage, indexed from zero. */
  /** Stages whose picture has been uncovered and kept. */
  collected: number[];
  /** Best clear time per stage, in milliseconds, indexed by stage - 1. */
  bestTimes: number[];
  /** Whether the player has been through, or skipped, the tutorial. */
  tutorialDone: boolean;
}

export interface Settings {
  musicOn: boolean;
  soundOn: boolean;
  /** Whether the phone buzzes on a pick, a clear and a refusal. */
  hapticsOn: boolean;
}

export function todayKey(now: Date = new Date()): string {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
}

/** App startup awaits initializeStorage before constructing any game screens. */
function read<T>(key: string, fallback: T, revive: (raw: unknown) => T): T {
  const raw = store.read(key);
  return raw === null ? fallback : revive(savedObject(raw));
}

function write(key: string, value: unknown): void {
  const previous = store.read(key);
  // Preserve additive fields introduced by another release instead of dropping
  // them when saving an older/partial representation of a record.
  store.write(key, JSON.stringify({
    ...(previous === null ? {} : savedObject(previous)),
    ...(value as Record<string, unknown>),
  }));
}

function blankDaily(): DailyStats {
  return { date: todayKey(), best: 0, games: 0 };
}

export function loadDaily(): DailyStats {
  return read(DAILY_KEY, blankDaily(), (raw) => {
    const parsed = raw as Partial<DailyStats>;
    if (parsed.date !== todayKey()) return blankDaily();
    return {
      date: parsed.date,
      best: Number(parsed.best) || 0,
      games: Number(parsed.games) || 0,
    };
  });
}

export function saveDaily(stats: DailyStats): void {
  write(DAILY_KEY, stats);
}

export function loadSettings(): Settings {
  // Both default to on: a game that is silent and still until it is switched
  // on is a game most players never hear.
  return read(SETTINGS_KEY, { musicOn: true, soundOn: true, hapticsOn: true }, (raw) => {
    const parsed = raw as Partial<Settings>;
    return { musicOn: parsed.musicOn !== false, soundOn: parsed.soundOn !== false, hapticsOn: parsed.hapticsOn !== false };
  });
}

export function saveSettings(settings: Settings): void {
  write(SETTINGS_KEY, settings);
}

function blankProgress(): Progress {
  return {
    stage: 1,
    bestStory: 0,
    bestTimeAttack: 0,
    bestTimeAttackLevels: [0, 0, 0, 0],
    learningStage: 1,
    bestLearningScore: 0,
    bestLimitlessScore: 0,
    bestEndless: 0,
    bestEndlessMs: 0,
    bestTimeless: 0,
    fewestLeft: -1,
    seenChapters: [],
    collected: [],
    bestTimes: [],
    tutorialDone: false,
  };
}

export function loadProgress(): Progress {
  return read(PROGRESS_KEY, blankProgress(), (raw) => {
    const parsed = raw as Partial<Progress>;
    const stage = Number(parsed.stage);
    return {
      stage: Number.isFinite(stage) ? Math.min(Math.max(stage, 1), TOTAL_STAGES) : 1,
      bestStory: Number(parsed.bestStory) || 0,
      bestTimeAttack: Number(parsed.bestTimeAttack) || 0,
      learningStage: Number.isSafeInteger(parsed.learningStage) && parsed.learningStage! > 0 ? parsed.learningStage! : 1,
      bestLearningScore: Number.isFinite(parsed.bestLearningScore) ? Math.max(0, parsed.bestLearningScore!) : 0,
      bestLimitlessScore: Number.isFinite(parsed.bestLimitlessScore) ? Math.max(0, parsed.bestLimitlessScore!) : 0,
      bestTimeAttackLevels: Array.from({ length: 4 }, (_, i) => {
        const score = Number(parsed.bestTimeAttackLevels?.[i]);
        return Number.isFinite(score) && score > 0 ? score : 0;
      }),
      bestEndless: Number(parsed.bestEndless) || 0,
      bestEndlessMs: Math.max(0, Number(parsed.bestEndlessMs) || 0),
      bestTimeless: Number(parsed.bestTimeless) || 0,
      // -1, not 0, because zero left is the perfect result and a fresh save
      // must not read as having already achieved it.
      fewestLeft: Number.isFinite(Number(parsed.fewestLeft)) ? Number(parsed.fewestLeft) : -1,
      seenChapters: Array.isArray(parsed.seenChapters)
        ? parsed.seenChapters.filter((id): id is string => typeof id === "string")
        : [],
      bestTimes: Array.isArray(parsed.bestTimes)
        ? parsed.bestTimes.map((n) => Math.max(0, Number(n) || 0))
        : [],
      collected: Array.isArray(parsed.collected)
        ? parsed.collected.map((n) => Number(n) || 0).filter((n) => n >= 1)
        : [],
      tutorialDone: parsed.tutorialDone === true,
    };
  });
}

export function saveProgress(progress: Progress): void {
  write(PROGRESS_KEY, progress);
}

/** Keeps the best grade a stage has ever earned. */
/** Adds a stage's picture to the collection. Collecting twice changes nothing. */
export function collectPlate(progress: Progress, stage: number): Progress {
  if (progress.collected.includes(stage)) return progress;
  return { ...progress, collected: [...progress.collected, stage].sort((a, b) => a - b) };
}

/** Records a clear time, keeping only the best one for that stage. */
export function recordStageTime(progress: Progress, stage: number, ms: number): Progress {
  const bestTimes = [...progress.bestTimes];
  while (bestTimes.length < stage) bestTimes.push(0);
  const held = bestTimes[stage - 1] ?? 0;
  if (held !== 0 && held <= ms) return progress;
  bestTimes[stage - 1] = ms;
  return { ...progress, bestTimes };
}

/** Records how long an endless run lasted, keeping only the longest. */
export function recordEndlessTime(progress: Progress, ms: number): Progress {
  if (ms <= progress.bestEndlessMs) return progress;
  return { ...progress, bestEndlessMs: ms };
}

export function bestTimeFor(progress: Progress, stage: number): number {
  return progress.bestTimes[stage - 1] ?? 0;
}

export function totalCollected(progress: Progress): number {
  return progress.collected.length;
}
